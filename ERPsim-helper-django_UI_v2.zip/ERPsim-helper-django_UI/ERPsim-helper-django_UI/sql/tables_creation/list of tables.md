All tables :
- Company_Valuation
- Current_Inventory
- Current_Inventory_KPI
- Current_Suppliers_Prices
- Financial_Balances
- Financial_Postings
- Good_Movements
- Independant_Requirements
- Inventory
- Market
- MRP_Runs
- NPS_Surveys
- Pricing_Conditions
- Purchase_Orders
- Sales
- Stock_Transfers
- Suppliers_Prices

Priorities :
- Sales
- Inventory
- Pricing_Conditions