SELECT 
table_name
FROM 
information_schema.tables
WHERE TABLE_SCHEMA = "erpsim_games";
